# PreopAI v0.1 — Multiempresa & Multivehículo

Este paquete contiene:
- backend/ (Node+Express+Prisma)
- mobile_app/templates (Flutter templates)
- scripts/ (install, start, backup, init_flutter)
- docs/ (Paso a Paso, Wompi, IA, Billing, Playbook)

Sigue `docs/00_PASO_A_PASO.md`.
