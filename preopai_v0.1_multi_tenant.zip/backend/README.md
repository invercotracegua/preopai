# PreopAI Backend (v0.1)

- Multiempresa y multivehículo
- Monedero por empresa + Precio por revisión (override por vehículo)
- Webhook de recargas (placeholder Wompi)
- Upload de imágenes con chequeo de resolución mínimo
- Prisma + PostgreSQL

Ver `docs/00_PASO_A_PASO.md` para instalar en el VPS.
