# PLAYBOOK_OPERATIVO.md

Roles:
- Admin: todo acceso
- Jefe Operativo: aprueba hallazgos, puede omitir cobro en casos excepcionales
- Conductor: sube revisiones y fotos

Bloqueos:
- Sin saldo => no crea revisión
- Hallazgo sin foto "después" => bloquear hasta aprobación
