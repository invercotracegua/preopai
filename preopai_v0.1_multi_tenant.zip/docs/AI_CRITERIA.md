# AI_CRITERIA.md

v0.1: Chequeo de resolución mínima con Sharp.
Próximos:
- Desenfoque (Varianza Laplaciano)
- Contraste
- Detección de duplicados (pHash)
- OCR de SOAT/licencia y validaciones contra DB
- Microservicio YOLO para fallas específicas (según dataset del cliente)
